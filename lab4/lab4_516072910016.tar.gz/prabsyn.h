/* function prototype from prabsyn.c */
void pr_exp(FILE *out, A_exp v, int d);

